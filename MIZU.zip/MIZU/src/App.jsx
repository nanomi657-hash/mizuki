import React, { useState, useEffect } from 'react';
import { 
  Search, Play, Star, ChevronRight, ArrowUp, Heart, 
  Clock, Flame, Calendar, Film, ListFilter, MessageSquare, 
  Share2, Eye, User, Sparkles, CheckCircle2, AlertCircle
} from 'lucide-react';

// KONFIGURASI SISTEM UTAMA
const API_BASE = 'http://localhost:5000/api';
const GENRES_LIST = [
  'Action', 'Adventure', 'Cars', 'Comedy', 'Demons', 
  'Drama', 'Fantasy', 'Game', 'Harem', 'Historical', 
  'Horror', 'Josei', 'Magic', 'Martial Arts', 'Mecha',
  'Military', 'Music', 'Mystery', 'Parody', 'Romance'
];

export default function App() {
  // --- STATE MANAGEMENT UTAMA ---
  const [activeTab, setActiveTab] = useState('ongoing');
  const [activeGenre, setActiveGenre] = useState(null);
  const [animeList, setAnimeList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAnime, setSelectedAnime] = useState(null);
  const [selectedEpisode, setSelectedEpisode] = useState(null);
  const [showScrollTop, setShowScrollTop] = useState(false);
  
  // --- STATE PERSISTENCE (LOCAL STORAGE) ---
  const [favorites, setFavorites] = useState([]);
  const [history, setHistory] = useState([]);
  
  // --- STATE FILTER & INTERAKSI TAMBAHAN ---
  const [filterType, setFilterType] = useState('all'); 
  const [filterStatus, setFilterStatus] = useState('all'); 
  const [commentInput, setCommentInput] = useState('');
  const [mockComments, setMockComments] = useState([
    { id: 1, user: 'KuroNeko', text: 'Gokil, grafiknya memanjakan mata banget eps kali ini!', time: '2 jam lalu' },
    { id: 2, user: 'WibuSepuh', text: 'Sesuai ekspektasi dari studionya, pacing cerita rapi.', time: '5 jam lalu' },
    { id: 3, user: 'RamenLover', text: 'Gak sabar nunggu kelanjutan minggu depan, gantung banget endingnya.', time: '1 hari lalu' }
  ]);

  // --- EFFECT: DETEKSI SCROLL (BACK TO TOP) ---
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // --- EFFECT: INITIAL LOAD DARI LOCAL STORAGE ---
  useEffect(() => {
    const savedFavs = localStorage.getItem('mizu_favs');
    const savedHist = localStorage.getItem('mizu_history');
    if (savedFavs) setFavorites(JSON.parse(savedFavs));
    if (savedHist) setHistory(JSON.parse(savedHist));
    
    if (!searchQuery && !activeGenre) {
      fetchList(activeTab);
    }
  }, [activeTab, searchQuery]);

  // --- ENGINE CORE: FETCH DATA BERANDA ---
  const fetchList = async (type) => {
    setLoading(true);
    setActiveGenre(null);
    try {
      const res = await fetch(`${API_BASE}/${type}`);
      const data = await res.json();
      setAnimeList(data.results || []);
    } catch (err) {
      console.error("Gagal mengambil data list:", err);
    } finally {
      setTimeout(() => setLoading(false), 1200);
    }
  };

  // --- ENGINE CORE: FILTER GENRE ---
  const handleGenreFilter = async (genreName) => {
    setLoading(true);
    setActiveGenre(genreName);
    setSearchQuery('');
    try {
      const res = await fetch(`${API_BASE}/genre/${genreName.toLowerCase()}`);
      const data = await res.json();
      setAnimeList(data.results || []);
    } catch (err) {
      console.error("Gagal memfilter genre:", err);
    } finally {
      setTimeout(() => setLoading(false), 1200);
    }
  };

  // --- ENGINE CORE: PENCARIAN ANIME ---
  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setLoading(true);
    setSelectedAnime(null);
    setSelectedEpisode(null);
    setActiveGenre(null);
    try {
      const res = await fetch(`${API_BASE}/search?q=${encodeURIComponent(searchQuery)}`);
      const data = await res.json();
      setAnimeList(data.results || []);
    } catch (err) {
      console.error("Gagal melakukan pencarian:", err);
    } finally {
      setTimeout(() => setLoading(false), 1200);
    }
  };

  // --- ENGINE CORE: PARSING DETAIL ANIME ---
  const handleAnimeClick = async (url) => {
    setLoading(true);
    setSelectedEpisode(null);
    try {
      const res = await fetch(`${API_BASE}/anime?url=${encodeURIComponent(url)}`);
      const data = await res.json();
      setSelectedAnime(data);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      alert("Gagal memuat detail anime dari server.");
    } finally {
      setTimeout(() => setLoading(false), 1000);
    }
  };

  // --- ENGINE CORE: VIDEO PLAYER & HISTORY LOGGER ---
  const handleEpisodeClick = async (epTitle, epUrl) => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/episode?url=${encodeURIComponent(epUrl)}`);
      const data = await res.json();
      setSelectedEpisode(data);
      
      const newHistoryItem = {
        animeTitle: selectedAnime.title,
        episodeTitle: epTitle,
        url: selectedAnime.url,
        thumbnail: selectedAnime.thumbnail,
        time: new Date().toLocaleDateString('id-ID')
      };
      
      const filteredHist = history.filter(h => h.url !== selectedAnime.url);
      const updatedHist = [newHistoryItem, ...filteredHist].slice(0, 15);
      setHistory(updatedHist);
      localStorage.setItem('mizu_history', JSON.stringify(updatedHist));

      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      alert("Gagal memuat sistem video player streaming.");
    } finally {
      setTimeout(() => setLoading(false), 1000);
    }
  };

  // --- UTILITY: BOOKMARK / FAVORIT ---
  const toggleFavorite = (animeItem, e) => {
    if (e) e.stopPropagation();
    let updated = [...favorites];
    const isExist = favorites.find(f => f.url === animeItem.url);
    
    if (isExist) {
      updated = updated.filter(f => f.url !== animeItem.url);
    } else {
      updated.push(animeItem);
    }
    setFavorites(updated);
    localStorage.setItem('mizu_favs', JSON.stringify(updated));
  };

  // --- UTILITY: SUBMIT KOMENTAR MOCK ---
  const handleSubmitComment = (e) => {
    e.preventDefault();
    if (!commentInput.trim()) return;
    const newComment = {
      id: Date.now(),
      user: 'Kamu (User)',
      text: commentInput,
      time: 'Baru saja'
    };
    setMockComments([newComment, ...mockComments]);
    setCommentInput('');
  };

  // --- ENGINE: CLIENT-SIDE ADVANCED FILTERING ---
  const filteredAnimeList = animeList.filter(anime => {
    const matchType = filterType === 'all' || (anime.type && anime.type.toLowerCase() === filterType);
    const matchStatus = filterStatus === 'all' || (anime.status && anime.status.toLowerCase() === filterStatus);
    return matchType && matchStatus;
  });

  return (
    <div className="min-h-screen font-sans pb-16 bg-slate-950 bg-gradient-to-b from-slate-950 via-slate-900 to-indigo-950/30 text-slate-100">
      
      {/* CUSTOM GLOBAL CORE CSS */}
      <style>{`
        .scrollbar-none::-webkit-scrollbar { display: none; }
        .scrollbar-none { -ms-overflow-style: none; scrollbar-width: none; }
        .custom-scroll::-webkit-scrollbar { width: 5px; height: 5px; }
        .custom-scroll::-webkit-scrollbar-track { background: #0b0f19; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 10px; }
        .custom-scroll::-webkit-scrollbar-thumb:hover { background: #06b6d4; }
      `}</style>

      {/* ========================================================================= */}
      {/* PREMIUM FULLSCREEN MINIMALIST LOADING SCREEN                 */}
      {/* ========================================================================= */}
      {loading && (
        <div className="fixed inset-0 z-[9999] bg-slate-950/95 backdrop-blur-sm flex flex-col items-center justify-center p-4 transition-all duration-300">
          {/* Box Container Diperkecil Maksimal (180px di HP, 240px di Desktop) */}
          <div className="w-full max-w-[180px] sm:max-w-[240px] aspect-square rounded-2xl overflow-hidden border border-slate-800/80 shadow-[0_0_40px_rgba(6,182,212,0.1)] relative bg-black">
            <iframe 
              src="https://www.kapwing.com/e/6a2d15774a7b9071a733ca50?autoplay=1&mute=1&loop=1" 
              className="absolute inset-0 w-full h-full pointer-events-none scale-110" // scale-110 buat motong sedikit border default bawaan kapwing
              allow="autoplay; gyroscope;" 
              referrerPolicy="strict-origin"
              title="MizuAnime Loading Stream"
            />
          </div>
          {/* Teks Status Loading yang Simpel */}
          <div className="mt-4 flex flex-col items-center gap-1">
            <p className="text-[10px] font-mono tracking-[0.3em] uppercase text-cyan-400 font-bold animate-pulse">
              LOADING...
            </p>
          </div>
        </div>
      )}

      {/* HEADER BAR PLATFORM */}
      <header className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/60 px-4 py-3.5 flex justify-between items-center gap-4">
        <div 
          className="flex items-center gap-2 cursor-pointer shrink-0" 
          onClick={() => { setSelectedAnime(null); setSelectedEpisode(null); setSearchQuery(''); setActiveGenre(null); fetchList('ongoing'); }}
        >
          <div className="bg-gradient-to-tr from-cyan-400 to-blue-500 p-2 rounded-xl shadow-[0_0_15px_rgba(6,182,212,0.4)]">
            <Sparkles className="w-4 h-4 text-slate-950 fill-slate-950" />
          </div>
          <span className="text-xl font-black tracking-wider bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
            MIZU<span className="text-slate-100 font-light">ANIME</span>
          </span>
        </div>

        {/* INPUT FORM PENCARIAN UTAMA */}
        <form onSubmit={handleSearch} className="relative w-full max-w-xs md:max-w-md">
          <input
            type="text"
            placeholder="Cari judul anime, studio, atau genre..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900/90 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/30 text-xs rounded-full pl-10 pr-4 py-2.5 outline-none text-slate-200 transition-all shadow-inner"
          />
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
        </form>

        <div className="hidden sm:flex items-center gap-2 text-[11px] font-mono bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-400">
          <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
          NODE STREAM V1.2
        </div>
      </header>

      {/* MAIN CONTAINER CONTENT VIEW */}
      <main className="max-w-7xl mx-auto p-4 space-y-6">
        
        {selectedAnime ? (
          /* ========================================================================= */
          /* LAYOUT 1: HALAMAN NONTON & DETAIL (CINEMATIC VIEW)                        */
          /* ========================================================================= */
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <button 
                onClick={() => { if(selectedEpisode) { setSelectedEpisode(null); } else { setSelectedAnime(null); } }}
                className="text-xs bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold px-4 py-2.5 rounded-xl transition-all flex items-center gap-2"
              >
                ← KEMBALI KE DISPLAY BERANDA
              </button>

              {selectedEpisode && (
                <div className="text-xs text-slate-400 font-medium">
                  Kamu sedang menonton: <span className="text-cyan-400 font-bold">{selectedEpisode.title}</span>
                </div>
              )}
            </div>

            {/* SCREEN LAYOUT VIDEO THEATER */}
            {selectedEpisode && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-4">
                  <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-black border-2 border-slate-900 shadow-2xl">
                    {selectedEpisode.embed_url ? (
                      <iframe 
                        src={selectedEpisode.embed_url} 
                        className="absolute inset-0 w-full h-full" 
                        allowFullScreen 
                        title="Streaming Core"
                      />
                    ) : (
                      <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-slate-900/60">
                        <AlertCircle className="w-12 h-12 text-rose-500 mb-2" />
                        <p className="text-xs text-slate-400">Tautan pemutar rusak atau memerlukan izin pemecahan bypass eksternal.</p>
                      </div>
                    )}
                  </div>

                  <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 flex justify-between items-center gap-4 flex-wrap">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-cyan-500/10 rounded-xl border border-cyan-500/20 text-cyan-400">
                        <Eye className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-200">{selectedEpisode.title}</h4>
                        <p className="text-[10px] text-slate-500">Auto Scaled Streaming Player Node Engine</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => { navigator.clipboard.writeText(window.location.href); alert('Link berhasil disalin!'); }}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5" /> BAGIKAN
                    </button>
                  </div>

                  {/* FORM INTERAKSI & KOMENTAR DISKUSI */}
                  <div className="bg-slate-900/30 border border-slate-800/40 rounded-2xl p-5 space-y-4">
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-cyan-400" /> Kolom Diskusi Warga ({mockComments.length})
                    </h3>
                    
                    <form onSubmit={handleSubmitComment} className="flex gap-2">
                      <input 
                        type="text" 
                        placeholder="Tulis opini atau komentar kamu tentang episode ini..." 
                        value={commentInput}
                        onChange={(e) => setCommentInput(e.target.value)}
                        className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 outline-none focus:border-cyan-500 transition-colors"
                      />
                      <button type="submit" className="bg-cyan-500 hover:bg-cyan-600 text-slate-950 text-xs font-bold px-4 rounded-xl transition-colors">
                        KIRIM
                      </button>
                    </form>

                    <div className="space-y-3 pt-2 max-h-60 overflow-y-auto custom-scroll pr-1">
                      {mockComments.map(comment => (
                        <div key={comment.id} className="bg-slate-950/50 p-3 rounded-xl border border-slate-900 flex items-start gap-3">
                          <div className="p-2 bg-slate-800 rounded-full text-slate-400 shrink-0">
                            <User className="w-3.5 h-3.5" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] font-black text-slate-300">{comment.user}</span>
                              <span className="text-[9px] text-slate-500 font-mono">{comment.time}</span>
                            </div>
                            <p className="text-xs text-slate-400 mt-0.5">{comment.text}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* SIDEBAR DAFTAR EPISODE JALUR CEPAT */}
                <div className="bg-slate-900/50 border border-slate-800/60 rounded-2xl p-4 h-fit space-y-4">
                  <div className="border-b border-slate-800 pb-2">
                    <h3 className="text-xs font-black uppercase tracking-widest text-slate-200 flex items-center gap-2">
                      <Film className="w-4 h-4 text-cyan-400" /> Navigasi Episode
                    </h3>
                    <p className="text-[10px] text-slate-500 mt-0.5">Klik nomor eps untuk langsung berpindah streaming</p>
                  </div>

                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-3 gap-2 max-h-96 overflow-y-auto pr-1 custom-scroll">
                    {selectedAnime.episodes?.map((ep) => (
                      <button 
                        key={ep.episode} 
                        onClick={() => handleEpisodeClick(`Episode ${ep.episode}`, ep.url)}
                        className="bg-slate-950 hover:bg-cyan-500 hover:text-slate-950 p-2.5 rounded-xl border border-slate-800 text-center text-xs font-bold transition-all truncate flex flex-col items-center justify-center gap-0.5 group"
                      >
                        <span className="text-[9px] text-slate-500 group-hover:text-slate-900 uppercase font-mono">EPS</span>
                        <span>{ep.episode}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* PANEL GRID PROFIL DETAIL KARAKTERISTIK ANIME */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 bg-slate-900/20 p-6 rounded-2xl border border-slate-800/40 backdrop-blur-md">
              <div className="md:col-span-1 flex flex-col items-center gap-4">
                <img 
                  src={selectedAnime.thumbnail} 
                  alt={selectedAnime.title} 
                  className="w-48 md:w-full rounded-2xl border border-slate-800 shadow-2xl object-cover aspect-[3/4]" 
                />
                
                <button 
                  onClick={() => toggleFavorite({ title: selectedAnime.title, url: selectedAnime.url, image: selectedAnime.thumbnail })}
                  className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition-all ${
                    favorites.find(f => f.url === selectedAnime.url)
                      ? 'bg-rose-500/20 text-rose-400 border-rose-500/40 shadow-lg shadow-rose-500/5'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-rose-500/40 hover:text-rose-400'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${favorites.find(f => f.url === selectedAnime.url) ? 'fill-rose-400' : ''}`} />
                  {favorites.find(f => f.url === selectedAnime.url) ? 'DISIMPAN DI FAVORIT' : 'TAMBAH KE FAVORIT'}
                </button>
              </div>
              
              <div className="md:col-span-3 space-y-5">
                <h1 className="text-xl md:text-3xl font-black text-white tracking-wide leading-tight">{selectedAnime.title}</h1>
                
                {/* MATRIKS METADATA SPESIFIK */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/40 p-3 rounded-xl border border-slate-900 font-medium text-xs">
                  <div><span className="text-slate-500 block text-[10px] uppercase font-mono">Status</span><span className="text-slate-200">{selectedAnime.status || '?'}</span></div>
                  <div><span className="text-slate-500 block text-[10px] uppercase font-mono">Tipe</span><span className="text-slate-200">{selectedAnime.type || 'TV Series'}</span></div>
                  <div><span className="text-slate-500 block text-[10px] uppercase font-mono">Skor</span><span className="text-yellow-400 font-bold flex items-center gap-0.5"><Star className="w-3 h-3 fill-yellow-400" /> {selectedAnime.score || '0.0'}</span></div>
                  <div><span className="text-slate-500 block text-[10px] uppercase font-mono">Studio</span><span className="text-slate-200 truncate block">{selectedAnime.studio || '?'}</span></div>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {selectedAnime.genres?.map((g, i) => (
                    <span key={i} className="bg-slate-900 text-slate-300 text-[10px] font-bold px-3 py-1 rounded-md border border-slate-800">
                      {g}
                    </span>
                  ))}
                </div>

                <div className="space-y-1.5">
                  <p className="text-[11px] font-black text-slate-400 tracking-widest uppercase border-b border-slate-800 pb-1">Sinopsis Resmi</p>
                  <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/20 p-4 rounded-xl border border-slate-900/60 shadow-inner">
                    {selectedAnime.synopsis || "Deskripsi naratif sinopsis belum diunggah secara menyeluruh oleh pihak penyedia server."}
                  </p>
                </div>

                {/* EXPANDED JALUR EPISODE DEFAULT */}
                {!selectedEpisode && (
                  <div className="space-y-3 pt-2">
                    <p className="text-xs font-black text-slate-200 tracking-wider uppercase border-l-2 border-cyan-500 pl-2">
                      Daftar Ekspansi Rilis Episode
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-2 max-h-52 overflow-y-auto pr-1 custom-scroll">
                      {selectedAnime.episodes?.map((ep) => (
                        <button 
                          key={ep.episode} 
                          onClick={() => handleEpisodeClick(`Episode ${ep.episode}`, ep.url)}
                          className="bg-slate-900 hover:bg-gradient-to-r hover:from-cyan-400 to-blue-500 hover:text-slate-950 text-xs font-bold p-3 rounded-xl border border-slate-800/80 text-left transition-all truncate flex items-center justify-between group"
                        >
                          <span>Eps {ep.episode}</span>
                          <Play className="w-3 h-3 opacity-0 group-hover:opacity-100 fill-current shrink-0" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            </div>
          </div>
        ) : (
          /* ========================================================================= */
          /* LAYOUT 2: MAIN BERANDA UTAMA PLATFORM (GRID LIST ANIME)                  */
          /* ========================================================================= */
          <div className="space-y-6">
            
            {/* HERO SPOTLIGHT DISPLAY BANNER */}
            {!searchQuery && !activeGenre && animeList.length > 0 && !loading && activeTab !== 'favorite' && activeTab !== 'history' && (
              <div className="relative rounded-3xl overflow-hidden bg-slate-900 border border-slate-800/80 shadow-2xl aspect-[16/9] md:aspect-[24/9] flex items-end group">
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent z-10" />
                <img 
                  src={animeList[0]?.image} 
                  alt="Spotlight Spotlight" 
                  className="absolute inset-0 w-full h-full object-cover opacity-25 object-center group-hover:scale-102 transition-transform duration-1000"
                />
                
                <div className="relative z-20 p-6 md:p-8 space-y-2 max-w-2xl">
                  <span className="inline-flex items-center gap-1 text-[10px] font-black uppercase tracking-widest bg-pink-500/20 text-pink-400 px-2.5 py-0.5 rounded border border-pink-500/30">
                    <Flame className="w-3 h-3 fill-pink-400" /> UPDATE REKOMENDASI TERKINI
                  </span>
                  <h2 className="text-xl md:text-3xl font-black text-white line-clamp-2 tracking-wide leading-tight">
                    {animeList[0]?.title}
                  </h2>
                  <div className="flex gap-2 pt-2">
                    <button 
                      onClick={() => handleAnimeClick(animeList[0].url)} 
                      className="flex items-center gap-2 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-500 hover:to-blue-600 text-slate-950 text-xs font-black px-6 py-3 rounded-full shadow-lg shadow-cyan-500/10 transition-transform active:scale-95"
                    >
                      <Play className="w-3.5 h-3.5 fill-slate-950" /> TONTON SEKARANG
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* SYSTEM QUICK CHIPS SELECTOR FILTER GENRE */}
            <div className="space-y-2">
              <div className="flex gap-2 overflow-x-auto pb-2.5 scrollbar-none snap-x px-1">
                <button 
                  onClick={() => { setActiveGenre(null); fetchList('ongoing'); }}
                  className={`snap-center shrink-0 text-xs font-bold px-4 py-2 rounded-full border transition-all ${
                    !activeGenre && searchQuery === '' && activeTab !== 'favorite' && activeTab !== 'history'
                      ? 'bg-gradient-to-r from-cyan-400 to-blue-500 border-transparent text-slate-950 shadow-lg shadow-cyan-500/20' 
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  Semua Library
                </button>
                {GENRES_LIST.map((genre, idx) => (
                  <button 
                    key={idx} 
                    onClick={() => handleGenreFilter(genre)}
                    className={`snap-center shrink-0 text-xs font-bold px-4 py-2 rounded-full border transition-all ${
                      activeGenre === genre 
                        ? 'bg-gradient-to-r from-cyan-400 to-blue-500 border-transparent text-slate-950 shadow-lg shadow-cyan-500/20' 
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    {genre}
                  </button>
                ))}
              </div>
            </div>

            {/* ADVANCED ADVANCED CONTROL TAB BAR OPTIONS */}
            {!searchQuery && !activeGenre && (
              <div className="flex flex-wrap gap-4 items-center justify-between border-b border-slate-800/60 pb-1">
                <div className="flex gap-4 overflow-x-auto scrollbar-none">
                  {[
                    { id: 'ongoing', label: 'Sedang Tayang', icon: Clock },
                    { id: 'popular', label: 'Terpopuler', icon: Flame },
                    { id: 'jadwal', label: 'Jadwal Rilis', icon: Calendar },
                    { id: 'favorite', label: 'Favorit Saya', icon: Heart },
                    { id: 'history', label: 'Riwayat Nonton', icon: CheckCircle2 }
                  ].map((tab) => {
                    const IconComponent = tab.icon;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => {
                          setActiveTab(tab.id);
                          if (tab.id === 'favorite') setAnimeList(favorites);
                          if (tab.id === 'history') setAnimeList(history);
                        }}
                        className={`text-xs font-bold uppercase tracking-wider pb-3 px-1 transition-all border-b-2 flex items-center gap-1.5 shrink-0 ${
                          activeTab === tab.id 
                            ? 'border-cyan-400 text-cyan-400 font-black' 
                            : 'border-transparent text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <IconComponent className="w-3.5 h-3.5" />
                        {tab.label}
                      </button>
                    );
                  })}
                </div>

                {/* FILTER DROPDOWN SYSTEM INTERNAL FRONTEND */}
                {activeTab !== 'favorite' && activeTab !== 'history' && (
                  <div className="flex items-center gap-2 pb-2 sm:pb-0">
                    <ListFilter className="w-3.5 h-3.5 text-slate-500" />
                    <select 
                      value={filterType} 
                      onChange={(e) => setFilterType(e.target.value)}
                      className="bg-slate-900 border border-slate-800 text-[11px] font-bold p-1.5 rounded-lg text-slate-300 outline-none focus:border-cyan-500"
                    >
                      <option value="all">Semua Tipe</option>
                      <option value="tv">TV Series</option>
                      <option value="movie">Movie</option>
                      <option value="ova">OVA</option>
                    </select>
                    
                    <select 
                      value={filterStatus} 
                      onChange={(e) => setFilterStatus(e.target.value)}
                      className="bg-slate-900 border border-slate-800 text-[11px] font-bold p-1.5 rounded-lg text-slate-300 outline-none focus:border-cyan-500"
                    >
                      <option value="all">Semua Status</option>
                      <option value="ongoing">Ongoing</option>
                      <option value="completed">Completed</option>
                    </select>
                  </div>
                )}
              </div>
            )}

            {/* NOTIFIKASI ELEMEN INDIKATOR FILTER PENCARIAN */}
            {searchQuery && (
              <div className="flex justify-between items-center bg-slate-900/30 p-3.5 rounded-xl border border-slate-800">
                <p className="text-xs text-slate-400">
                  Hasil pencarian aktif untuk kata kunci: <span className="text-cyan-400 font-black">"{searchQuery}"</span>
                </p>
                <button onClick={() => { setSearchQuery(''); fetchList('ongoing'); }} className="text-[10px] font-black text-rose-400 hover:underline">
                  CLEAR KEYWORD
                </button>
              </div>
            )}

            {/* NOTIFIKASI ELEMEN INDIKATOR FILTER GENRE */}
            {activeGenre && (
              <div className="flex justify-between items-center bg-slate-900/30 p-3.5 rounded-xl border border-slate-800">
                <p className="text-xs text-slate-400">
                  Menampilkan katalog genre: <span className="text-cyan-400 font-black">"{activeGenre}"</span>
                </p>
                <button onClick={() => { setActiveGenre(null); fetchList('ongoing'); }} className="text-[10px] font-black text-rose-400 hover:underline">
                  HAPUS GENRE
                </button>
              </div>
            )}

            {/* CATALOG LIST DISPLAY GRID */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {activeTab === 'history' ? (
                /* DISPLAY HISTORY NONTON */
                history.map((hist, index) => (
                  <div 
                    key={index}
                    onClick={() => handleAnimeClick(hist.url)}
                    className="group bg-slate-900/40 border border-slate-800 rounded-2xl p-2.5 cursor-pointer transition-all hover:-translate-y-1 relative"
                  >
                    <div className="relative aspect-[3/4] bg-slate-950 rounded-xl overflow-hidden mb-2.5">
                      <img src={hist.thumbnail} alt={hist.animeTitle} className="object-cover w-full h-full" />
                      <div className="absolute inset-0 bg-black/60 flex flex-col justify-end p-2">
                        <span className="text-[9px] text-cyan-400 font-black tracking-wide uppercase">Terakhir Nonton:</span>
                        <span className="text-[11px] text-white font-bold truncate">{hist.episodeTitle}</span>
                      </div>
                    </div>
                    <h3 className="text-xs font-bold text-slate-300 line-clamp-1 group-hover:text-cyan-400">{hist.animeTitle}</h3>
                    <p className="text-[9px] text-slate-500 font-mono mt-0.5">{hist.time}</p>
                  </div>
                ))
              ) : (
                /* DISPLAY KATALOG STANDAR */
                filteredAnimeList.map((anime, index) => (
                  <div 
                    key={index}
                    onClick={() => handleAnimeClick(anime.url)}
                    className="group bg-slate-900/40 border border-slate-800/80 hover:border-slate-700/80 rounded-2xl p-2.5 cursor-pointer transition-all hover:-translate-y-1.5 shadow-xl flex flex-col justify-between relative overflow-hidden"
                  >
                    <div className="relative aspect-[3/4] bg-slate-950 rounded-xl overflow-hidden mb-2.5">
                      <img 
                        src={anime.image} 
                        alt={anime.title} 
                        className="object-cover w-full h-full group-hover:scale-103 transition-transform duration-500" 
                        loading="lazy" 
                      />
                      
                      {/* PLACEMENT TAG METADATA FLOATING CARD */}
                      {anime.type && (
                        <span className="absolute top-2 right-2 bg-slate-950/80 backdrop-blur-md text-cyan-400 border border-slate-800 text-[9px] font-black px-2 py-0.5 rounded-md shadow-md uppercase font-mono">
                          {anime.type}
                        </span>
                      )}
                      {anime.rating && (
                        <span className="absolute top-2 left-2 bg-slate-950/90 backdrop-blur-md text-yellow-400 text-[9px] font-bold px-1.5 py-0.5 rounded-md flex items-center gap-0.5 border border-slate-800">
                          <Star className="w-2.5 h-2.5 fill-yellow-400 text-yellow-400" /> {anime.rating}
                        </span>
                      )}
                      {anime.episode && (
                        <span className="absolute bottom-2 left-2 bg-slate-950/90 backdrop-blur-md text-slate-200 text-[9px] font-bold px-2 py-0.5 rounded-md border border-slate-800/60">
                          {anime.episode}
                        </span>
                      )}

                      <button 
                        onClick={(e) => { e.stopPropagation(); toggleFavorite(anime); }}
                        className="absolute bottom-2 right-2 p-1.5 rounded-md bg-slate-950/80 backdrop-blur-md text-slate-400 hover:text-rose-400 transition-colors"
                      >
                        <Heart className="w-3.5 h-3.5 fill-current text-slate-400" style={{ color: favorites.find(f => f.url === anime.url) ? '#f43f5e' : '' }} />
                      </button>
                    </div>

                    <h3 className="text-xs font-bold text-slate-300 line-clamp-2 group-hover:text-cyan-400 transition-colors px-1" title={anime.title}>
                      {anime.title}
                    </h3>
                  </div>
                ))
              )}
            </div>

            {/* EMPTY STATE DATA HANDLER */}
            {((activeTab === 'history' && history.length === 0) || (activeTab === 'favorite' && favorites.length === 0) || (activeTab !== 'history' && activeTab !== 'favorite' && filteredAnimeList.length === 0)) && (
              <div className="text-center py-28 text-xs text-slate-500 border border-dashed border-slate-800 rounded-2xl bg-slate-900/10 space-y-2">
                <p className="font-mono text-slate-400 uppercase tracking-widest text-[10px]">CACHE_EMPTY_OR_NOT_FOUND</p>
                <p className="text-[11px] text-slate-600">Tidak ada paket data elemen anime yang tersedia di memori filter saat ini.</p>
              </div>
            )}

          </div>
        )}
      </main>

      {/* BUTTON STICKY BACK TO TOP ELEMENT */}
      {showScrollTop && !selectedAnime && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-6 right-6 z-50 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-500 hover:to-blue-600 text-slate-950 p-3 rounded-full shadow-2xl transition-all active:scale-90 border border-cyan-300/20"
          title="Scroll Ke Atas"
        >
          <ArrowUp className="w-5 h-5 stroke-[2.5]" />
        </button>
      )}

    </div>
  );
}
